==============================================
Thanks for your support / Gracias por apoyarme
   Made by SrJulioXD / Hecho por SrJulioXD
==============================================

EN: If you require any extra help or want to request a 
personalized menu, you can contact me through Discord.

ES: Si requieres de alguna ayuda extra o quieres pedir un 
menu personalizado puedes contactarme por Discord.

🔰 DISCORD: SrJulio#8220


=============================================
----------HOW TO MAKE THE MENU WORK----------
=============================================

🔰 To make the menu work you just have to place the wallet_config.yml 
file inside the menu plugin you use and at the same time use the texturepack.

🔰 If you want the placeholders to work you must have these plugins installed:
⬛ https://www.spigotmc.org/resources/placeholderapi.6245/
⬛ https://www.spigotmc.org/resources/vault.34315/
⬛ https://www.spigotmc.org/resources/playtime.26016/

🔰 You must have these PlaceHolderAPI extensions installed
⬛ player
⬛ playtime
⬛ server
⬛ vault


=============================================
-------COMO HACER QUE EL MENU FUNCIONE-------
=============================================

🔰 Para que el menú funcione solo debes colocar el archivo "wallet _config.yml" dentro 
del plug-in de menus que usa y al mismo tiempo use el paquete de texturas.

🔰 Si desea que los placeholders funcionen, debe tener estos plug-ins instalados:
⬛ https://www.spigotmc.org/resources/placeholderapi.6245/
⬛ https://www.spigotmc.org/resources/vault.34315/
⬛ https://www.spigotmc.org/resources/playtime.26016/

🔰 También debe tener estas extensiones de PlaceHolderAPI instaladas:
⬛ player
⬛ playtime
⬛ server
⬛ vault