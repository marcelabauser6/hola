Dear valued customer, we at Boxpix Studio would like to express our sincerest
gratitude for your recent purchase. Thank you for choosing our product.

Support discord: https://discord.gg/xe7raWPp6z

Terms and Conditions:
1.Upon buying this product, you are acknowledging and accepting the Terms of Service.
2.It is prohibited to resell, share, or take credit for this product.
3.Due to the digital nature of the product, all purchases are considered final and non-refundable.
4.We cannot be held liable if you lose or delete the product after purchasing it, and we are unable to provide a refund or replacement.
5.The Terms of Service are subject to change at any given moment without prior notice.

# 682658BJZDUFRKN5KBTLM4